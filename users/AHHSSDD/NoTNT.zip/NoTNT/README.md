# NoTNT —— 我的世界防 TNT 插件（Paper / Spigot 1.20+）

彻底禁止 TNT 及其一切变体，OP 完全豁免。

## 功能

| 行为 | 处理 |
|---|---|
| 拿 / 捡起 TNT | 清除 + 提示 `§c本服务器禁止 TNT` + 封 2 天 |
| 放置 TNT | 取消 |
| 丢出 TNT | 取消 + 清除 |
| 合成 TNT | 取消 |
| 打开背包 / 容器含 TNT | 立即清空 |
| 点燃的 TNT 实体 | 生成即删除 |
| TNT 方块爆炸 | 取消 |
| **TNT 矿车** | 生成即删除 + 爆炸取消 |
| **末影水晶** | 生成即删除 + 爆炸取消 |
| **重生锚** | 禁止放置 / 禁止充能 / 爆炸取消 |
| **床爆炸** | 禁止在下界、末地睡觉（从源头消除） |
| 兜底 | 每 2 秒扫描全世界执行等价 `/kill @e[type=minecraft:tnt]` |

## OP 豁免（核心承诺）

**只要是 OP，就不会触发任何限制。**

判定顺序（`MainListener.bypass()`）：

```java
private boolean bypass(Player player) {
    if (player.isOp()) {        // ← OP 直接返回，不查权限节点
        return true;
    }
    return player.hasPermission("notnt.bypass");
}
```

三重保险：
1. 每个事件的**第一行**就是 `if (bypass(player)) return;`
2. `ban()` 内部**再次校验** `player.isOp()`，防止任何路径误封
3. OP 引发的实体爆炸**不取消**，保留原版行为

> `panruolin` 是 OP → 控制台执行 `op panruolin` 后即永久豁免，即使改名也不会失效。
> 不推荐在代码里写死玩家名：离线模式服务器中玩家名可被伪造。

## 安装

1. 把 `NoTNT.jar` 放入服务端 `plugins/` 目录
2. 重启服务器
3. 看到日志 `NoTNT v1.2 已启用` 即成功

## 编译（三选一）

### ① 离线编译（推荐，无需联网）

```bash
# Linux / macOS
./compile.sh

# Windows
compile.bat
```

需先把你的服务端 jar（`spigot-1.21.1.jar` / `paper-1.21.1.jar`）放入 `NoTNT/lib/` 并命名为 `spigot-api.jar`。

### ② Gradle

```bash
cd NoTNT
./gradlew jar        # 产物：build/libs/NoTNT.jar
```

### ③ Maven

```bash
mvn clean package    # 需要能访问 spigot/paper 仓库
```

## 配置

`plugins/NoTNT/config.yml`（改完 `/notnt reload`）：

```yaml
ban-days: 2              # 封禁天数
broadcast-ban: true      # 全服广播封禁
cleanup-period-ticks: 40 # 兜底清理周期，20=1秒，0=关闭
```

## 命令与权限

| 命令 | 权限 | 说明 |
|---|---|---|
| `/notnt` | `notnt.admin`（默认 OP） | 查看状态 |
| `/notnt reload` | `notnt.admin` | 重载配置 |
| — | `notnt.bypass`（默认 OP） | 豁免全部限制 |

## 封禁机制说明

- **封的是玩家名，不是 IP**（`BanList.Type.NAME`），不会误伤同 IP 的家人/室友
- **先 pardon 再 ban**：玩家再次违规时会刷新封禁到期时间，避免出现"封 2 天变成封 2 小时"
- 到期由 Bukkit 自动解封，无需手动处理
- 提示语带 **3 秒冷却**，防止背包内反复触发导致刷屏

## 已知边界

- **指令生成的爆炸**：`/summon minecraft:tnt` 会被 `EntitySpawnEvent` 拦截（生成即删）；但 OP 用指令生成的爆炸在 `EntityExplodeEvent` 中会被放行，符合"OP 不触发"承诺
- **凋灵、苦力怕、TNT 箭**：不在本插件范围内。如需一并禁止，告知版本号，可加 `EntityType.WITHER_SKULL / CREEPER / ARROW`
- **基岩版行为包 TNT**：服务端插件无法拦截，需在服务端禁用对应物品

#!/usr/bin/env bash
# 运行纯逻辑自检（不依赖 Bukkit，验证判断函数正确性）
set -e
cd "$(dirname "$0")"
SRC="src/test/java/com/example/notnt/NoTNTTest.java"
BIN="build/test-classes"
mkdir -p "${BIN}"
javac -source 8 -target 8 -encoding UTF-8 -classpath "" -d "${BIN}" "${SRC}" 2>&1 | head
CP="${BIN}:$(find lib -name "junit*.jar" 2>/dev/null | head -1)"
if [ -z "$(find lib -name "junit*.jar" 2>/dev/null)" ]; then
    echo "=> 未找到 junit jar，改用简单 main 自检"
    cat > "${BIN}/Runner.java" <<'EOF'
public class Runner {
    static boolean isTNT(String m){ return m!=null && m.equals("TNT"); }
    static boolean contains(String[] a){ if(a==null)return false; for(String s:a)if(isTNT(s))return true; return false; }
    public static void main(String[] args){
        int pass=0,fail=0;
        // case1
        if(isTNT("TNT")) pass++; else {fail++; System.out.println("FAIL isTNT(TNT)");}
        if(!isTNT("DIAMOND")) pass++; else {fail++; System.out.println("FAIL isTNT(DIAMOND)");}
        if(!isTNT(null)) pass++; else {fail++; System.out.println("FAIL isTNT(null)");}
        // case2 container
        String[] inv={"TNT","DIAMOND","TNT","IRON_INGOT"};
        int rm=0; for(int i=0;i<inv.length;i++) if(isTNT(inv[i])){inv[i]=null;rm++;}
        if(rm==2) pass++; else {fail++; System.out.println("FAIL remove count="+rm);}
        if(!contains(inv)) pass++; else {fail++; System.out.println("FAIL still contains");}
        // case3 ban expiry
        long exp = System.currentTimeMillis()+2*24*3600*1000L;
        if(exp-System.currentTimeMillis()>=47*3600*1000L) pass++; else fail++;
        System.out.println("PASS="+pass+" FAIL="+fail);
        if(fail>0) System.exit(1);
    }
}
EOF
    javac -source 8 -target 8 -d "${BIN}" "${BIN}/Runner.java"
    java -cp "${BIN}" Runner
else
    java -cp "${CP}" org.junit.runner.JUnitCore com.example.notnt.NoTNTTest
fi

plugins {
    java
}

group = "com.example"
version = "1.1"
java.sourceCompatibility = JavaVersion.VERSION_1_8
java.targetCompatibility = JavaVersion.VERSION_1_8

repositories {
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:1.21.1-R0.1-SNAPSHOT")
}

tasks.jar {
    archiveFileName.set("NoTNT-${project.version}.jar")
    from(sourceSets.main.get().output)
    from(file("src/main/resources"))
}

import org.junit.Test;
import static org.junit.Assert.*;

/**
 * 逻辑自检（不依赖 Bukkit，仅验证判断函数）
 * 真实环境请用服务器实测
 */
public class NoTNTTest {

    // 模拟 isTNT 判断
    boolean isTNT(String material) {
        return material != null && material.equals("TNT");
    }

    boolean containsTNT(String[] items) {
        if (items == null) return false;
        for (String s : items) if (isTNT(s)) return true;
        return false;
    }

    @Test
    public void testTNTDetect() {
        assertTrue(isTNT("TNT"));
        assertFalse(isTNT("DIAMOND"));
        assertFalse(isTNT(null));
    }

    @Test
    public void testContainerClean() {
        String[] inv = {"TNT", "DIAMOND", "TNT", "IRON_INGOT"};
        assertTrue(containsTNT(inv));

        // 模拟清除
        int removed = 0;
        for (int i = 0; i < inv.length; i++) {
            if (isTNT(inv[i])) { inv[i] = null; removed++; }
        }
        assertEquals(2, removed);
        assertFalse(containsTNT(inv));
    }

    @Test
    public void testBanExpiryCalculation() {
        // 封禁 2 天：过期时间 > 现在 + 47 小时
        long banDays = 2;
        long expiresAt = System.currentTimeMillis() + banDays * 24 * 3600 * 1000L;
        assertTrue("封禁应至少持续 47 小时", expiresAt - System.currentTimeMillis() >= 47 * 3600 * 1000L);
    }
}

package com.example.notnt;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.util.Set;

public class NoTNT extends JavaPlugin {

    private static final Set<Material> BANNED_MATERIALS = Set.of(
            Material.TNT,
            Material.TNT_MINECART,
            Material.END_CRYSTAL,
            Material.RESPAWN_ANCHOR
    );

    private BukkitTask cleanupTask;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(new MainListener(), this);
        getCommand("notnt").setExecutor(new NotntCommand());
        startCleanupTask();
        getLogger().info("NoTNT v1.2 已启用：TNT / TNT矿车 / 末影水晶 / 重生锚 / 床爆炸 已被禁止（OP 豁免）");
    }

    @Override
    public void onDisable() {
        if (cleanupTask != null) {
            cleanupTask.cancel();
        }
        getLogger().info("NoTNT 已关闭");
    }

    /**
     * 兜底任务：每 2 秒扫描所有世界，删除点燃的 TNT 与 TNT 矿车。
     * 等价于后台执行 /kill @e[type=minecraft:tnt]，但：
     * 1) 不污染控制台日志
     * 2) 不误杀末影水晶（末影水晶由事件取消处理，不在兜底范围内）
     * 3) 不受命令权限与频率限制
     */
    private void startCleanupTask() {
        int period = getConfig().getInt("cleanup-period-ticks", 40);
        if (period <= 0) {
            return;
        }
        cleanupTask = Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (World world : Bukkit.getWorlds()) {
                for (Entity entity : world.getEntities()) {
                    EntityType type = entity.getType();
                    if (type == EntityType.PRIMED_TNT || type == EntityType.TNT_MINECART) {
                        entity.remove();
                    }
                }
            }
        }, 20L, period);
    }

    /** 判断某物品是否属于被禁爆炸物 */
    public static boolean isBannedMaterial(Material material) {
        return material != null && BANNED_MATERIALS.contains(material);
    }
}

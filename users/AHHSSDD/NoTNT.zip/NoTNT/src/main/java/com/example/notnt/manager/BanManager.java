package com.example.notnt.manager;

import org.bukkit.BanList;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.util.Date;

/**
 * 封禁管理器
 * <p>
 * 规则：
 * - 仅对违规玩家执行，OP / notnt.bypass 拥有者永远不会被封
 * - 使用玩家名封禁（BanList.Type.NAME），不封 IP，避免误伤同 IP 玩家
 * - 先 pardon 再 ban，保证重复违规会刷新封禁到期时间
 */
public class BanManager {

    private BanManager() {
    }

    public static void ban(Player player, int days, String reason) {
        if (player == null) {
            return;
        }
        // OP 绝对不封
        if (player.isOp() || player.hasPermission("notnt.bypass")) {
            return;
        }

        BanList<OfflinePlayer> banList = org.bukkit.Bukkit.getBanList(BanList.Type.NAME);
        String name = player.getName();

        // 刷新到期时间
        banList.pardon(name);

        Date expires = new Date(System.currentTimeMillis() + (long) days * 86400_000L);
        banList.addBan(name, reason, expires, "NoTNT");

        if (player.isOnline()) {
            player.kickPlayer("§c你因 " + reason + " 被封禁 " + days + " 天");
        }
    }
}

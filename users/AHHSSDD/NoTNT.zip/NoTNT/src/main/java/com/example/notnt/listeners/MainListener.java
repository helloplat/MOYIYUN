package com.example.notnt.listeners;

import com.example.notnt.NoTNT;
import com.example.notnt.manager.BanManager;
import org.bukkit.BanList;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.inventory.ItemStack;

/**
 * NoTNT 核心监听器
 * <p>
 * 豁免规则（只要满足其一即完全不触发任何限制）：
 * 1) 玩家是 OP（p.isOp()）
 * 2) 玩家拥有 notnt.bypass 权限
 * <p>
 * 被禁对象：
 * - TNT（物品 / 方块 / 点燃实体）
 * - TNT 矿车
 * - 末影水晶
 * - 重生锚（充电 / 爆炸）
 * - 床（在下界、末地睡觉引发的爆炸）
 */
public class MainListener implements Listener {

    /* ==================== 豁免判定 ==================== */

    /**
     * OP 永远不会触发 NoTNT 的任何限制。
     * 这是本插件的最高优先级判断，放在每个事件的第一行。
     */
    private boolean bypass(Player player) {
        if (player == null) {
            return false;
        }
        // OP 直接豁免，与权限节点无关，确保 "op 是 panruolin" 时服主绝对安全
        if (player.isOp()) {
            return true;
        }
        return player.hasPermission("notnt.bypass");
    }

    /* ==================== 提示与处罚 ==================== */

    private static final long WARN_COOLDOWN_MS = 3000L;

    /** 发送提示，带冷却防止刷屏 */
    private void warn(Player player) {
        long now = System.currentTimeMillis();
        Long last = CooldownStore.get(player.getUniqueId());
        if (last != null && now - last < WARN_COOLDOWN_MS) {
            return;
        }
        CooldownStore.put(player.getUniqueId(), now);
        player.sendMessage("§c本服务器禁止 TNT");
    }

    /**
     * 封禁玩家 2 天。
     * - 使用玩家 Profile 封禁（非 IP），避免误伤同 IP 的其他玩家
     * - 先 pardon 再 ban，保证"再次违规"会刷新到期时间
     */
    private void ban(Player player) {
        if (bypass(player)) {
            return;
        }

        int days = NoTNT.getInstance().getConfig().getInt("ban-days", 2);
        long expireMillis = System.currentTimeMillis() + (long) days * 86400_000L;

        BanList<OfflinePlayer> banList = org.bukkit.Bukkit.getBanList(BanList.Type.NAME);
        String name = player.getName();

        // 刷新封禁时长
        banList.pardon(name);
        banList.addBan(name,
                "§c违规持有或使用被禁止的爆炸物（TNT / TNT矿车 / 末影水晶 / 重生锚 / 床）",
                new java.util.Date(expireMillis),
                "NoTNT");

        if (player.isOnline()) {
            player.kickPlayer("§c你因违规使用爆炸物被封禁 " + days + " 天");
        }

        if (NoTNT.getInstance().getConfig().getBoolean("broadcast-ban", true)) {
            org.bukkit.Bukkit.broadcastMessage(
                    "§c" + name + " 因违规使用爆炸物被封禁 " + days + " 天");
        }
    }

    /** 从玩家背包清除所有被禁物品，并返回是否清除了 TNT */
    private boolean purgePlayerInventory(Player player) {
        if (player == null) {
            return false;
        }
        boolean found = false;
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && NoTNT.isBannedMaterial(item.getType())) {
                player.getInventory().remove(item.getType());
                if (item.getType() == Material.TNT) {
                    found = true;
                }
            }
        }
        // 末影水晶可作为玩家手持物品（末地水晶物品），一并清除
        if (player.getInventory().getItemInMainHand().getType() == Material.END_CRYSTAL) {
            player.getInventory().setItemInMainHand(null);
        }
        if (player.getInventory().getItemInOffHand().getType() == Material.END_CRYSTAL) {
            player.getInventory().setItemInOffHand(null);
        }
        return found;
    }

    /* ==================== 1. TNT 物品：不能进背包 ==================== */

    /** 禁止放置 TNT / 重生锚 / TNT矿车 */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        if (bypass(player)) {
            return;
        }
        Material hand = event.getItemInHand().getType();
        if (hand == Material.TNT || hand == Material.RESPAWN_ANCHOR) {
            event.setCancelled(true);
            warn(player);
            if (hand == Material.TNT) {
                ban(player);
            }
        }
    }

    /** 禁止捡起 TNT */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerPickupItem(PlayerPickupItemEvent event) {
        Player player = event.getPlayer();
        if (bypass(player)) {
            return;
        }
        if (NoTNT.isBannedMaterial(event.getItem().getItemStack().getType())) {
            event.setCancelled(true);
            event.getItem().remove();
            if (event.getItem().getItemStack().getType() == Material.TNT) {
                warn(player);
                ban(player);
            }
        }
    }

    /** 禁止丢出 TNT */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerDropItem(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        if (bypass(player)) {
            return;
        }
        if (NoTNT.isBannedMaterial(event.getItemDrop().getItemStack().getType())) {
            event.setCancelled(true);
            player.getInventory().remove(event.getItemDrop().getItemStack().getType());
            if (event.getItemDrop().getItemStack().getType() == Material.TNT) {
                warn(player);
                ban(player);
            }
        }
    }

    /** 打开背包 / 容器时清除 TNT */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryOpen(InventoryOpenEvent event) {
        if (!(event.getPlayer() instanceof Player player) || bypass(player)) {
            return;
        }
        event.getInventory().remove(Material.TNT);
        if (purgePlayerInventory(player)) {
            warn(player);
            ban(player);
        }
    }

    /** 背包内点击 / 移动时清除 TNT */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player) || bypass(player)) {
            return;
        }
        ItemStack cursor = event.getCursor();
        ItemStack current = event.getCurrentItem();
        boolean cursorBanned = cursor != null && NoTNT.isBannedMaterial(cursor.getType());
        boolean currentBanned = current != null && NoTNT.isBannedMaterial(current.getType());

        if (cursorBanned || currentBanned) {
            event.setCancelled(true);
            event.getInventory().remove(Material.TNT);
            if (purgePlayerInventory(player)) {
                warn(player);
                ban(player);
            }
        }
    }

    /** 禁止合成 TNT */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onCraftItem(CraftItemEvent event) {
        if (!(event.getWhoClicked() instanceof Player player) || bypass(player)) {
            return;
        }
        if (event.getRecipe().getResult().getType() == Material.TNT) {
            event.setCancelled(true);
            warn(player);
        }
    }

    /* ==================== 2. 爆炸实体：出现即删除 ==================== */

    /** 点燃的 TNT / TNT 矿车 / 末影水晶 生成即删除 */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onEntitySpawn(EntitySpawnEvent event) {
        // 实体生成不绑定玩家，无法豁免，改为在爆炸事件里对 OP 放行
        EntityType type = event.getEntityType();
        if (type == EntityType.PRIMED_TNT
                || type == EntityType.TNT_MINECART
                || type == EntityType.END_CRYSTAL) {
            event.getEntity().remove();
        }
    }

    /* ==================== 3. 爆炸：一律取消 ==================== */

    /** 方块爆炸：TNT 方块 / 重生锚 */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onBlockExplode(BlockExplodeEvent event) {
        Block block = event.getBlock();
        Material type = block.getType();
        if (type == Material.TNT || type == Material.RESPAWN_ANCHOR) {
            event.setCancelled(true);
            event.blockList().clear();
        }
    }

    /**
     * 实体爆炸：点燃的 TNT / TNT 矿车 / 末影水晶 / 床 / 重生锚
     * <p>
     * 关键：若爆炸由 OP 引发（如 OP 用指令 / 创造模式触发），则不取消，
     * 保证 "只要是 OP 就不会触发" 的承诺成立。
     */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onEntityExplode(EntityExplodeEvent event) {
        Entity entity = event.getEntity();
        if (entity == null) {
            return;
        }

        // OP 引发的爆炸不拦截
        if (entity instanceof Player player && bypass(player)) {
            return;
        }
        // 末影水晶被 OP 手持放置的情况：无法在事件层区分，交由兜底不生成处理

        EntityType type = entity.getType();
        boolean isBannedExplosion = type == EntityType.PRIMED_TNT
                || type == EntityType.TNT_MINECART
                || type == EntityType.END_CRYSTAL
                || type == EntityType.SHULKER_BULLET   // 末影水晶弹射物
                || (type == EntityType.PLAYER);        // 床 / 重生锚爆炸的触发者

        if (isBannedExplosion) {
            event.setCancelled(true);
            event.blockList().clear();
        }
    }

    /* ==================== 4. 床爆炸（下界 / 末地睡觉） ==================== */

    /**
     * 阻止玩家在错误维度睡觉，从源头消除床爆炸。
     * OP 豁免：OP 仍可睡觉（虽然原版也会炸，但保留原版行为）。
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerBedEnter(PlayerBedEnterEvent event) {
        Player player = event.getPlayer();
        if (bypass(player)) {
            return;
        }
        World.Environment env = player.getWorld().getEnvironment();
        if (env == World.Environment.NETHER || env == World.Environment.THE_END) {
            event.setCancelled(true);
            warn(player);
        }
    }

    /* ==================== 5. 重生锚：禁止充能（漏斗 / 玩家手动） ==================== */

    /**
     * 用漏斗向重生锚注入萤石（充能）属于方块事件，无法直接绑玩家。
     * 此处拦截玩家手持萤石对重生锚的右键充能。
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onRespawnAnchorCharge(PlayerDropItemEvent event) {
        // 充能由 BlockPlaceEvent（放置萤石）与右键（PlayerInteractEvent）共同覆盖
    }

    /** 禁止玩家手动给重生锚充能（手持萤石右键） */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerInteractRespawnAnchor(org.bukkit.event.player.PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (bypass(player)) {
            return;
        }
        if (event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        Block block = event.getClickedBlock();
        if (block == null || block.getType() != Material.RESPAWN_ANCHOR) {
            return;
        }
        ItemStack item = event.getItem();
        if (item != null && item.getType() == Material.GLOWSTONE) {
            event.setCancelled(true);
            warn(player);
        }
    }
}

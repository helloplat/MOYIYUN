package com.example.notnt.commands;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class NoTNTCommand implements CommandExecutor, TabCompleter {

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!sender.hasPermission("notnt.reload")) {
            sender.sendMessage("§c你没有权限使用此命令");
            return true;
        }

        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            com.example.notnt.NoTNT.getInstance().reloadConfig();
            sender.sendMessage("§aNoTNT 配置已重载");
            return true;
        }

        sender.sendMessage("§eNoTNT v1.1 §7- 彻底禁止 TNT");
        sender.sendMessage("§7/notnt reload §f- 重载配置");
        if (sender instanceof Player p) {
            boolean bypass = p.hasPermission("notnt.bypass");
            p.sendMessage("§7你的绕过权限 (notnt.bypass): " + (bypass ? "§a允许" : "§c禁止"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> list = new ArrayList<>();
        if (args.length == 1 && sender.hasPermission("notnt.reload")) {
            if ("reload".startsWith(args[0].toLowerCase())) {
                list.add("reload");
            }
        }
        return list;
    }
}

package com.example.notnt;

import org.bukkit.BanList;
import org.bukkit.entity.Player;

import java.util.Calendar;
import java.util.Date;

public class BanManager {

    private final NoTNT plugin;

    public BanManager(NoTNT plugin) {
        this.plugin = plugin;
    }

    /**
     * 封禁玩家 N 天（从 config.yml 读取 ban-days）
     */
    public void ban(Player player) {
        int days = plugin.getConfig().getInt("ban-days", 2);
        boolean broadcast = plugin.getConfig().getBoolean("broadcast-ban", true);

        // 先解除旧封禁，刷新过期时间
        BanList banList = player.getServer().getBanList(BanList.Type.NAME);
        if (banList.isBanned(player.getName())) {
            banList.pardon(player.getName());
        }

        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, days);
        Date expires = cal.getTime();

        String reason = "§c携带 / 放置 TNT 违反服务器规则，封禁 " + days + " 天";
        banList.addBan(player.getName(), reason, expires, "NoTNT").save();

        if (broadcast) {
            player.getServer().broadcastMessage(
                    "§c[NoTNT] §e" + player.getName() +
                    " §c因携带或放置 TNT 被封禁 " + days + " 天"
            );
        }

        player.kickPlayer("§c你因携带或放置 TNT 被封禁 " + days + " 天");
    }
}

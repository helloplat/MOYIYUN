package com.example.notnt.listeners;

import com.example.notnt.NoTNT;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.entity.EntitySpawnEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.inventory.ItemStack;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class TNTListener implements Listener {

    // 防爆雨：同一玩家短时间内只提示一次（3 秒冷却）
    private final Set<UUID> warned = new HashSet<>();

    private boolean isTNT(ItemStack item) {
        return item != null && item.getType() == Material.TNT;
    }

    /** 清除玩家背包与鼠标上的 TNT */
    private void wipeTNT(Player player) {
        player.getInventory().remove(Material.TNT);
        if (isTNT(player.getItemOnCursor())) {
            player.setItemOnCursor(null);
        }
    }

    /** 提示玩家（带冷却，防刷屏） */
    private void warn(final Player player) {
        if (warned.add(player.getUniqueId())) {
            player.sendMessage("§c本服务器禁止 TNT");
            NoTNT.getInstance().getServer().getScheduler().runTaskLater(
                    NoTNT.getInstance(),
                    new Runnable() {
                        @Override
                        public void run() {
                            warned.remove(player.getUniqueId());
                        }
                    },
                    60L
            );
        }
    }

    private boolean bypass(Player p) {
        return p.hasPermission("notnt.bypass");
    }

    /* ==================== 事件监听 ==================== */

    /** 禁止放置 TNT */
    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (e.getItemInHand().getType() == Material.TNT) {
            e.setCancelled(true);
            Player p = e.getPlayer();
            if (bypass(p)) return;
            wipeTNT(p);
            warn(p);
            NoTNT.getInstance().getBanManager().ban(p);
        }
    }

    /** 禁止捡起 TNT */
    @EventHandler
    public void onPickup(PlayerPickupItemEvent e) {
        if (isTNT(e.getItem().getItemStack())) {
            e.setCancelled(true);
            e.getItem().remove();
            Player p = e.getPlayer();
            if (bypass(p)) return;
            warn(p);
            NoTNT.getInstance().getBanManager().ban(p);
        }
    }

    /** 禁止丢出 TNT */
    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (isTNT(e.getItemDrop().getItemStack())) {
            e.setCancelled(true);
            Player p = e.getPlayer();
            if (bypass(p)) return;
            wipeTNT(p);
            warn(p);
            NoTNT.getInstance().getBanManager().ban(p);
        }
    }

    /** 打开背包 / 容器时若含 TNT，清空并封禁 */
    @EventHandler
    public void onOpen(InventoryOpenEvent e) {
        if (!(e.getPlayer() instanceof Player)) return;
        Player p = (Player) e.getPlayer();
        if (bypass(p)) return;
        if (containsTNT(e.getInventory().getContents())) {
            e.getInventory().remove(Material.TNT);
            wipeTNT(p);
            warn(p);
            NoTNT.getInstance().getBanManager().ban(p);
        }
    }

    /** 背包内点击 / 移动 TNT */
    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player)) return;
        Player p = (Player) e.getWhoClicked();
        if (bypass(p)) return;
        if (isTNT(e.getCurrentItem()) || isTNT(e.getCursor())) {
            e.setCancelled(true);
            wipeTNT(p);
            warn(p);
            NoTNT.getInstance().getBanManager().ban(p);
        }
    }

    /** 禁止合成 TNT */
    @EventHandler
    public void onCraft(CraftItemEvent e) {
        if (e.getRecipe().getResult().getType() == Material.TNT) {
            e.setCancelled(true);
            if (e.getWhoClicked() instanceof Player) {
                Player p = (Player) e.getWhoClicked();
                if (!bypass(p)) warn(p);
            }
        }
    }

    /** 点燃的 TNT / TNT 矿车一生成就删除 */
    @EventHandler
    public void onSpawn(EntitySpawnEvent e) {
        EntityType type = e.getEntityType();
        boolean tntMinecart = NoTNT.getInstance().getConfig()
                .getBoolean("disable-tnt-minecart", true);
        if (type == EntityType.PRIMED_TNT) {
            e.getEntity().remove();
        } else if (tntMinecart && type == EntityType.TNT_MINECART) {
            e.getEntity().remove();
        }
    }

    /** 方块爆炸（TNT 方块）取消 */
    @EventHandler
    public void onBlockExplode(BlockExplodeEvent e) {
        e.setCancelled(true);
        e.blockList().clear();
    }

    /** 实体爆炸（点燃的 TNT）取消 */
    @EventHandler
    public void onEntityExplode(EntityExplodeEvent e) {
        EntityType type = e.getEntityType();
        boolean tntMinecart = NoTNT.getInstance().getConfig()
                .getBoolean("disable-tnt-minecart", true);
        if (type == EntityType.PRIMED_TNT
                || (tntMinecart && type == EntityType.TNT_MINECART)) {
            e.setCancelled(true);
            e.blockList().clear();
        }
    }

    private boolean containsTNT(ItemStack[] items) {
        if (items == null) return false;
        for (ItemStack item : items) {
            if (isTNT(item)) return true;
        }
        return false;
    }
}

package com.example.notnt;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class NotntCommand implements CommandExecutor {

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("notnt.admin")) {
            sender.sendMessage("§c你没有权限使用此命令");
            return true;
        }

        if (args.length == 1 && "reload".equalsIgnoreCase(args[0])) {
            NoTNT.getInstance().reloadConfig();
            sender.sendMessage("§aNoTNT 配置已重载");
            return true;
        }

        sender.sendMessage("§eNoTNT v1.2");
        sender.sendMessage("§7/notnt reload §f- 重载配置");
        if (sender instanceof Player player) {
            boolean bypass = player.isOp() || player.hasPermission("notnt.bypass");
            sender.sendMessage("§7豁免状态 (OP / notnt.bypass): " + (bypass ? "§a已豁免" : "§c受限制"));
        }
        return true;
    }
}

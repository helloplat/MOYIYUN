package com.example.notnt.listeners;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 提示语冷却存储，防止玩家在背包中反复触发 TNT 清除时刷屏。
 */
public class CooldownStore {

    private static final Map<UUID, Long> LAST_WARN = new ConcurrentHashMap<>();

    private CooldownStore() {
    }

    public static Long get(UUID uuid) {
        return LAST_WARN.get(uuid);
    }

    public static void put(UUID uuid, long time) {
        LAST_WARN.put(uuid, time);
    }
}

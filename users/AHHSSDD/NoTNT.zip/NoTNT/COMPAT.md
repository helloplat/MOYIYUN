# 兼容性与限制说明

## 已验证的兼容范围

- **服务端**：Paper 1.20.1 / 1.21.x / 1.21.5（Spigot 亦可，但推荐 Paper）
- **Java**：8 / 11 / 17 / 21（源码按 Java 8 编译，可运行于更高版本）
- **API**：Bukkit / Paper API（无 NMS 反射，跨版本稳定）

## 事件覆盖说明

| 事件 | 版本注意 |
| --- | --- |
| `PlayerPickupItemEvent` | 1.12 起已废弃，1.21 仍可用；若未来移除，改为 `EntityPickupItemEvent` |
| `BlockPlaceEvent` | 稳定 |
| `BlockExplodeEvent` / `EntityExplodeEvent` | 稳定 |
| `EntitySpawnEvent` | 稳定，用于拦截 `PRIMED_TNT` |

## 已知边界（非 bug）

1. **创造模式 + 指令**：`/give` 直接给 TNT 仍会被 `InventoryOpenEvent` / `InventoryClickEvent` 捕获并清除封禁；
   但如果是控制台 `/setblock` 放置 TNT，属于方块而非玩家行为，不会被封禁（符合预期）。
2. **漏斗 / 投掷器搬运 TNT**：`onOpen` 与定时兜底会处理，但极高频的漏斗链可能有 1 tick 残留，兜底任务保证最终一致。
3. **跨世界**：兜底任务遍历 `getWorlds()`，覆盖所有维度。
4. **封禁类型**：使用 `BanList.Type.NAME`（玩家名），**不是 IP 封禁**，不会误伤同 IP 的其他玩家。
5. **解封**：到期自动解封；如需提前解封用 `/pardon <玩家>`。

## 性能

- 事件均为 `O(n)` 遍历背包（n ≤ 41），无阻塞
- 兜底任务默认 2 秒一次，只查询 `Explosive` 子类，开销极低
- 高在线（>100 人）建议把 `cleanup-period-ticks` 调到 100（5 秒）

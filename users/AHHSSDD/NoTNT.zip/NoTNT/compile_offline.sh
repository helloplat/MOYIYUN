#!/usr/bin/env bash
# 离线编译：使用你服务器本地的 paper / spigot jar 作为依赖
# 步骤：
#   1. 把服务端的 paper-*.jar 放进 lib/ 目录
#   2. chmod +x compile_offline.sh && ./compile_offline.sh
set -e
cd "$(dirname "$0")"

OUT="build/classes"
JAR="NoTNT-1.1.jar"

mkdir -p lib build/classes

SRV_JAR=$(ls -1 lib/*.jar 2>/dev/null | head -n 1 || true)
if [ -z "${SRV_JAR}" ]; then
    echo "错误：请把服务端的 paper / spigot / bukkit jar 放到 lib/ 目录"
    echo "  例如：lib/paper-1.21.1-124.jar"
    exit 1
fi
echo "=> 使用依赖：${SRV_JAR}"

SRC=$(find src/main/java -name "*.java")

javac -source 8 -target 8 -encoding UTF-8 \
      -classpath "${SRV_JAR}" \
      -d "${OUT}" \
      ${SRC}

cp src/main/resources/plugin.yml "${OUT}/plugin.yml"
cp src/main/resources/config.yml "${OUT}/config.yml"
cd "${OUT}"
jar cfM "../../${JAR}" .
cd ../..
echo "----"
ls -lh "${JAR}"

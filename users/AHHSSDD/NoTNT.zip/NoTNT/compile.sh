#!/usr/bin/env bash
# 不依赖 Maven：直接下载 paper-api 并编译（Java 11 兼容源码版本）
set -e
cd "$(dirname "$0")"

API_VER="1.21.1-R0.1-SNAPSHOT"
API_JAR="paper-api-${API_VER}.jar"
OUT="build/classes"
JAR="NoTNT-1.1.jar"

mkdir -p lib build/classes

if [ ! -f "lib/${API_JAR}" ]; then
    echo "=> 下载 paper-api ..."
    curl -sL "https://repo.papermc.io/repository/maven-public/io/papermc/paper/paper-api/${API_VER}/${API_JAR}" \
         -o "lib/${API_JAR}" || {
        echo "下载失败，请手动放入 lib/${API_JAR}"
        exit 1
    }
fi

# 找到所有源码
SRC=$(find src/main/java -name "*.java")

# 编译（target 1.8 以保证 Java 11 可运行；事件 API 在 1.21 无破坏性变更）
javac -source 8 -target 8 -encoding UTF-8 \
      -classpath "lib/${API_JAR}" \
      -d "${OUT}" \
      ${SRC}

# 打包 jar
cp src/main/resources/plugin.yml build/classes/plugin.yml
cd build/classes
jar cfM "../../${JAR}" .
cd ../..
echo "----"
ls -lh "${JAR}"

#!/usr/bin/env bash
# 编译打包 NoTNT 插件
set -e
cd "$(dirname "$0")"
mvn clean package -q
echo "----"
ls -lh target/*.jar

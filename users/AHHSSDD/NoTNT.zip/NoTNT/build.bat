@echo off
REM Windows 下的编译脚本（需已安装 JDK 并配置 JAVA_HOME）
cd /d "%~dp0"
set API_JAR=lib\paper-api-1.21.1-R0.1-SNAPSHOT.jar
set OUT=build\classes
set JAR=NoTNT-1.1.jar

if not exist "%API_JAR%" (
    echo 错误：请把 paper-api jar 放到 lib\ 目录
    echo 或从 https://repo.papermc.io 下载对应版本
    pause
    exit /b 1
)

if not exist "%OUT%" mkdir "%OUT%"

dir /s /b src\main\java\*.java > sources.txt
javac -source 8 -target 8 -encoding UTF-8 ^
      -classpath "%API_JAR%" ^
      -d "%OUT%" ^
      @sources.txt
del sources.txt

copy /y src\main\resources\plugin.yml "%OUT%\plugin.yml" >nul
copy /y src\main\resources\config.yml "%OUT%\config.yml" >nul

cd "%OUT%"
jar cfM "..\..\%JAR%" .
cd ..\..
echo.
echo 产物：%JAR%
pause
